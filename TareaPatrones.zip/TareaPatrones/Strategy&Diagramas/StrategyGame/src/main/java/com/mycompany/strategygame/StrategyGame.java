/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.strategygame;

import GUI.MainFrame;

/**
 *
 * @author josed
 */
public class StrategyGame {

    public static void main(String[] args) {
        new MainFrame();
    }
}
